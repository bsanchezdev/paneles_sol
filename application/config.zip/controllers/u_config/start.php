<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of start
 *
 * @author Desarrollo
 */
class start extends CI_Controller{
    
    public function __construct() {
        parent::__construct();
        $this->session->sess_destroy();
    }
    
    public function index()
    {
        $this->load->view("u_config/new_db_conect_view");   
    }
}
