select * from cuadratura
