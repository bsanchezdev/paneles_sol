select CUOTA,OPERACION,concat(CUOTA,OPERACION) from carga
