UPDATE `carga` SET `PAGADO`='SI' (`OPERACION`='%operacion%') AND (`CUOTA`='%cuota%')
