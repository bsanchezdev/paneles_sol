<div class="navbar navbar-default navbar-fixed-bottom">
    <div class="container">
      <p class="navbar-text pull-left">© 2015.
           <a href="http://www.solvencia.cl" target="_blank" >SOLVENCIA.CL</a>
      </p>
      
      <!--<a href="http://youtu.be/zJahlKPCL9g" class="navbar-btn btn-danger btn pull-right">
      <span class="glyphicon glyphicon-star"></span>  Subscribe on YouTube</a>-->
    </div>
    
    
  </div>