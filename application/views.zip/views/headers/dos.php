<div class="row">
        <hr class="hr-danger" />
        <ol class="breadcrumb bread-danger">
            <button href="#" class="btn btn-danger"><i class="fa fa-paw"></i> <a href="<?= base_url();?>"><i class="fa fa-home">&nbsp;</i>HOME</a></button>
              <li><a href="#">CELEBRITY</a></li>
              <li><a href="#">MOVIES</a></li>
              <li class="active">MUSIC</li>
          </ol>
        </div> 
 <?php $this->load->view("headers/navbar.php");?>