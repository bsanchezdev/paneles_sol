<div class="row" style="margin-top: -39px; height: 155px;">
                <div style="position: relative; top: 51px; color: rgb(249, 191, 25); font-size: 27px; z-index: 200; left: -30px; float: right;"></div>
                <div class="col-md-12" >
                <img src="<?=base_url("/imagenes/header.png")?>" style="width: 100%; height: 120px;" />
                </div>    
               <div style="position: relative; z-index: 100009; float: right; top: -37px;">
                   <img src="<?= base_url("/imagenes/solvencia/LOGO SOLVENCIA1.png");?>" style="width: 170px;"/>
               </div> 
            </div>
            <p>
                
                <?php $this->load->view("headers/navbar.php");?>